package five.main;

public class Main {
    public static void main(String[] args) {
        char ch = 'r';

        if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
            System.out.println("Vowel");
        }else {
            System.out.println("Consonant");
        }
    }
}